<?php
	$Server = "localhost";
	$User   = "root";
	$Pass   = "A7mdsayed";
	$DBname = "-shop-";
	Connect($Server,$User,$Pass,$DBname);
