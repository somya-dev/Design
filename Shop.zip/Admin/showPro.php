<?php
	session_start();
	$UserID = $_SESSION['UserID'];
	include 'init.php';
	$ProID = $_GET['ProID'];

		
$stmt = $con->prepare("SELECT * FROM products WHERE ProID=? LIMIT 1 ");
$stmt->execute(array($ProID));
$rows = $stmt->fetchAll();
if (! empty($rows)) {
	foreach($rows as $row) {
		echo '
		<div class="container dash">
				<h1>Product Info</h1>
				<hr/>
				<div class="col-sm-12">
					<div style="margin-bottom:10px" class="row">
						<div class="col-sm-4">
							<img src="Data/'.$row['ProImg'].'" width="100%" />
						</div>
						<div class="col-sm-8">
							<p><b>Name:</b> '.$row['ProTitle'].'</p>
							<p>'.$row['ProDesc'].'</p>
							<hr/>
							<p><b>Price:</b>  '.$row['ProPrice'].'.</p>
							<p><b>Quantity:</b>  '.$row['ProQuantity'].'.</p>
						</div>
					</div>

				</div>
			</div>
			<a style="margin-top:20px;width: 90%;text-align: center;margin: 0 auto;" href="users.php" class="btn btn-danger btn-block btn-sm">Back To users</a>

';
	}
}
	include $DirTemp.'Footer.php';
?>