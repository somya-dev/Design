<?php
include 'init.php';
$MsgID = $_GET['ConID'];
if($_GET['Status'] == 2){
	$stmt1 = $con->prepare("UPDATE contact SET Status = 1 WHERE ConID = ?");
	$stmt1->execute(array($MsgID));
}

$stmt = $con->prepare("SELECT * FROM contact WHERE ConID = ?");
$stmt->execute(array($MsgID));
$rows = $stmt->fetchAll();
if (! empty($rows)) {
	foreach($rows as $row) {
		
		$stmt1 = $con->prepare("SELECT * FROM users WHERE UserID = ?");
		$stmt1->execute(array($row['UserID']));
		$rows1 = $stmt1->fetchAll();
		if (! empty($rows1)) {
			foreach($rows1 as $row1) {
				$username = $row1['Username'];
			}
		}
		
		if($row['Status']==2){
			$Status = 'UnRead';
		}else if($row['Status']==1){
			$Status = 'Readed-Not Answer';
		}else{
			$Status = 'Answered';
		}
		echo '
			<div class="container">
				<div class="col-sm-12">
					<div class="col-sm-4">
						<ul>
							<li><b>Name: </b>'.$username.'</li>
							<li><b>Status: </b>'.$Status.'</li>
						</ul>
					</div>
					<div class="col-sm-8">
						<b>Msg:-</b>
						<p>'.$row['Msg'].'</p>';
		if(isset($_GET['Answer'])&& $_GET['Answer'] == true){
			echo '
			<hr>
			<div class="container">
				<b>Answer</b>
				<textarea class="form-control" rows="4"></textarea>
				<button class="btn btn-primary btn-block">Answer</button>
			</div>
			<hr/>
			';
		}
							
				echo '
					</div>
				</div>
				<br/><br/>
				<div class="col-sm-12">
					<div class="row">
						<div class="col-sm-6"><a style="margin-top:2%" href="messages.php" class="btn btn-danger btn-sm btn-block">Back</a></div>
						<div class="col-sm-6"><a style="margin-top:2%" href="?ConID='.$_GET['ConID'].'&&Answer=true" class="btn btn-success btn-sm btn-block">Answer</a></div>
					</div>
				</div>
			</div>
		';	
	}
}