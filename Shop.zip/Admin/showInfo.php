<?php
	session_start();
	$UserID = $_SESSION['UserID'];
	include 'init.php';
	$UserIDInfo = $_GET['UserID'];

		
$stmt = $con->prepare("SELECT * FROM users WHERE UserID=? LIMIT 1 ");
$stmt->execute(array($UserIDInfo));
$rows = $stmt->fetchAll();
if (! empty($rows)) {
	foreach($rows as $row) {
		if($row['GroupID']==1){$type="User";}else{$type="Admin";}
		if($row['Activation']==1){$active="Verfied";}else{$active="Not Verfied";}
		echo '
		<div class="container dash">
				<h1>User Info</h1>
				<hr/>
				<div class="col-sm-12">
					<div style="margin-bottom:10px" class="row">
						<div class="col-sm-4">
							<img src="Data/'.$row['Avatar'].'" width="100%" />
						</div>
						<div class="col-sm-8">
							<p><b>Name:</b> '.$row['Username'].'</p>
							<p><b>Email:</b>  '.$row['Email'].'.</p>
							<p><b>Password:</b>  '.$row['Password'].'.</p>
							<p><b>Type:</b>  '.$type.'.</p>
							<p><b>Activtion:</b>  '.$active.'.</p>
						</div>
					</div>

				</div>
			</div>
			<a style="margin-top:20px;width: 90%;text-align: center;margin: 0 auto;" href="users.php" class="btn btn-danger btn-block btn-sm">Back To users</a>

';
	}
}
	include $DirTemp.'Footer.php';
?>