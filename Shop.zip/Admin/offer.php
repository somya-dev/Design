<?php
	include 'init.php';

	if($_SERVER['REQUEST_METHOD']=="POST"){
		$value = $_POST['value'];
		$stmt = $con->prepare("UPDATE `products` SET `ProOffers` = ? WHERE `products`.`ProID` = ? ");
		$stmt->execute(array($value,$_GET['ProID']));
		header("Location: offers.php");
	}
?>
				<div class="container">
					<div class="col-sm-12">
						<div class="row">
							
							<div class="col-sm-12">
								<form action="<?php echo $_SEREVER['PHP_SELF'];?>" method="POST">
									<label>New Offer:</label>
									<input name="value" class="form-control" />
									<button class="btn btn-primary btn-block" type="submit">Offer</button>
								</form>
							</div>
						</div>
					</div>
				</div>
