<?php
	session_start();
	$UserID = $_SESSION['UserID'];
	include 'init.php';
?>
	<div class="container dash">
		<h1>الرسائــل</h1>
		<hr/>
		<br/>
		
		<table class="table table-hover table-bordered">
			<thead class="thead-dark ">
				<tr style="color:white;font-weight:bold" class="bg-dark ">
					<td class="col-sm-2">#ID</td>
					<td class="col-sm-3">Username</td>
					<td class="col-sm-3">Type</td>
					<td style="text-align:center" class="col-sm-4">Manage</td>
				</tr>
			</thead>
			<tbody>
				<?php
					$stmt = $con->prepare("SELECT * FROM contact ORDER BY ConID DESC");
					$stmt->execute();
					$rows = $stmt->fetchAll();
					if (! empty($rows)) {
						foreach($rows as $row) {
							
							
							$stmt1 = $con->prepare("SELECT * FROM users WHERE UserID = ?");
							$stmt1->execute(array($row['UserID']));
							$rows1 = $stmt1->fetchAll();
							if (! empty($rows1)) {
								foreach($rows1 as $row1) {
									$username = $row1['Username'];
								}
							}
							
							if($row['Status']==2){
								$Status = 'UnRead';
								echo '<tr style="background:#fac7c7">';
							}else if($row['Status']==1){
								$Status = 'Readed-Not Answer';
								echo '<tr style="background:#f8fac7">';
							}else{
								$Status = 'Answered';
								echo '<tr>';
							}
							echo '
								
									<td>'.$row['ConID'].'</td>
									<td>'.$username.'</td>
									<td>'.$Status.'</td>
									<td style="text-align:center">
										<a href="showMsg.php?ConID='.$row['ConID'].'&&Status='.$row['Status'].'" class="btn btn-primary btn-sm">Read</a>
										<a href="delete.php?Type=Msgs&&ConID='.$row['ConID'].'" class="btn btn-danger btn-sm">Delete</a>
										<a href="showMsg.php?ConID='.$row['ConID'].'&&Status='.$row['Status'].'&&Answer=true" class="btn btn-warning btn-sm">Answer</a>
									</td>
								</tr>
							';
						}
					}
				?>
			</tbody>
		</table>
	</div>
<?php
	include $DirTemp.'Footer.php';
?>